package com.buscador.buscadorontology.clases;

import java.util.ArrayList;

import com.buscador.buscadorontology.ConsultasBuscador;

public class BaseInformacion {
protected ConsultasBuscador consultaBuscador;

	public BaseInformacion() {
	  consultaBuscador = new ConsultasBuscador();	
	  
	}
	
}
