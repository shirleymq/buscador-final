package com.buscador.buscadorontology.clases;

public class QuesoSuave extends Queso{

	public QuesoSuave(String id, String d, String p, String n, String o) {
		super(id, d, p, n,  o);
		// TODO Auto-generated constructor stub
	}

}
